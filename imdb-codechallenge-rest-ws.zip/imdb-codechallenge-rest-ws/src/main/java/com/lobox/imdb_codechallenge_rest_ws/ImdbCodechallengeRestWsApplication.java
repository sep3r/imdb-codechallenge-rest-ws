package com.lobox.imdb_codechallenge_rest_ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImdbCodechallengeRestWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImdbCodechallengeRestWsApplication.class, args);
	}

}
